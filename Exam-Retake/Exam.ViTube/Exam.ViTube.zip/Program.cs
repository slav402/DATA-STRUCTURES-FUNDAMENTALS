﻿using System;

namespace Exam.ViTube
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var video = new Video("1", "asd", 1.34, 0, 0, 0);
            var user = new User("1", "slav");

            ViTubeRepository viTube = new ViTubeRepository();

            viTube.PostVideo(video);
            viTube.RegisterUser(user);

            viTube.WatchVideo(user, video);
            viTube.LikeVideo(user, video);
           
        }
    }
}
